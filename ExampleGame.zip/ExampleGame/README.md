# PhinyxEngine Example Game

**Author:** Alpeche Pancha

This is the example game made with the PhinyxEngine. Level files can be found in the data folder and may be modified freely. Control the character using the keys `A`, `D` and `Space bar`.

## Credits

[Player sprite](https://opengameart.org/content/cute-girl-free-sprites) by [pzUH](https://opengameart.org/users/pzuh) and licensed under [CC0](http://creativecommons.org/publicdomain/zero/1.0/).

[Platform tiles](https://opengameart.org/content/platform-tiles-0) by [Alucard](https://opengameart.org/users/alucard) and licensed under [CC BY 3.0](http://creativecommons.org/licenses/by/3.0/).

[Background image](https://opengameart.org/content/background-night) by [Alekei](https://opengameart.org/users/alekei) and licensed under [CC BY 3.0](http://creativecommons.org/licenses/by/3.0/).